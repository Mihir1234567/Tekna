// src/pages/QuotePreview.jsx
import React, { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Download, ArrowLeft } from "lucide-react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import logo from "../assets/logo.png";

/* ---------- Helpers ---------- */
function formatINR(v) {
  const n = Number(v) || 0;
  return (
    "₹" +
    n.toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  );
}

/* ---------- Window sketch SVG ---------- */
function WindowSketch({ width = 36, height = 48, type = "normal", label }) {
  const W = Math.max(1, Number(width));
  const H = Math.max(1, Number(height));

  const boxW = 220;
  const boxH = 160;

  const aspect = W / H;
  let rectW = boxW;
  let rectH = boxH;

  if (aspect > boxW / boxH) {
    rectW = boxW;
    rectH = Math.round(boxW / aspect);
  } else {
    rectH = boxH;
    rectW = Math.round(boxH * aspect);
  }

  const offsetX = (boxW - rectW) / 2 + 24;
  const offsetY = (boxH - rectH) / 2 + 10;

  const frame = "#0b1220";
  const glass = "#dbeffc";
  const sliderLeft = "#cbd6da";

  return (
    <svg
      width={boxW + 120}
      height={boxH + 90}
      viewBox={`0 0 ${boxW + 120} ${boxH + 90}`}
      xmlns="http://www.w3.org/2000/svg"
    >
      {label ? (
        <text
          x={(boxW + 120) / 2}
          y="18"
          textAnchor="middle"
          fontSize="12"
          fontWeight="600"
          fill="#111827"
        >
          {label}
        </text>
      ) : null}

      <rect
        x={offsetX - 6}
        y={offsetY - 6}
        width={rectW + 12}
        height={rectH + 12}
        rx="6"
        fill={frame}
      />

      <rect
        x={offsetX - 2}
        y={offsetY - 2}
        width={rectW + 4}
        height={rectH + 4}
        rx="4"
        fill="#0b1220"
      />

      {type === "slider" ? (
        <>
          <rect
            x={offsetX}
            y={offsetY}
            width={rectW / 2}
            height={rectH}
            rx="3"
            fill={sliderLeft}
          />
          <rect
            x={offsetX + rectW / 2}
            y={offsetY}
            width={rectW / 2}
            height={rectH}
            rx="3"
            fill={glass}
          />
          <rect
            x={offsetX + rectW / 2 - 3}
            y={offsetY - 6}
            width="6"
            height={rectH + 12}
            fill={frame}
          />
        </>
      ) : (
        <rect
          x={offsetX}
          y={offsetY}
          width={rectW}
          height={rectH}
          rx="3"
          fill={glass}
        />
      )}

      <rect
        x={offsetX}
        y={offsetY}
        width={rectW}
        height={rectH}
        fill="none"
        stroke={frame}
        strokeWidth="2"
      />

      <line
        x1={offsetX}
        y1={offsetY + rectH + 28}
        x2={offsetX + rectW}
        y2={offsetY + rectH + 28}
        stroke="#6b7280"
        strokeDasharray="2 2"
      />

      <text
        x={offsetX + rectW / 2}
        y={offsetY + rectH + 48}
        textAnchor="middle"
        fontSize="11"
        fill="#374151"
      >
        {W}" (width)
      </text>

      <line
        x1={offsetX + rectW + 28}
        y1={offsetY}
        x2={offsetX + rectW + 28}
        y2={offsetY + rectH}
        stroke="#6b7280"
        strokeDasharray="2 2"
      />

      <text
        x={offsetX + rectW + 46}
        y={offsetY + rectH / 2}
        fontSize="11"
        fill="#374151"
        transform={`rotate(90 ${offsetX + rectW + 46} ${offsetY + rectH / 2})`}
      >
        {H}" (height)
      </text>
    </svg>
  );
}

/* ---------- Main Component ---------- */
export default function QuotePreview() {
  const { state } = useLocation();
  const navigate = useNavigate();

  const [windowList, setWindowList] = useState(() => {
    if (Array.isArray(state?.windowList)) {
      return state.windowList;
    }
    const saved = localStorage.getItem("windowList");
    return saved ? JSON.parse(saved) : [];
  });

  const [applyGST, setApplyGST] = useState(false);
  const [cgstPerc, setCgstPerc] = useState(9);
  const [sgstPerc, setSgstPerc] = useState(9);

  const [isPDF, setIsPDF] = useState(false);

  const mainRef = useRef(null);

  const subtotal = windowList.reduce((s, w) => s + Number(w.amount || 0), 0);
  const cgstAmount = applyGST ? (subtotal * cgstPerc) / 100 : 0;
  const sgstAmount = applyGST ? (subtotal * sgstPerc) / 100 : 0;
  const grandTotal = subtotal + cgstAmount + sgstAmount;

  /* ---------- PDF generation ---------- */
  const downloadPDF = async () => {
    const container = mainRef.current;

    container.classList.add("pdf-mode");
    setIsPDF(true);

    setTimeout(async () => {
      const pdf = new jsPDF("p", "mm", "a4");

      // Load logo image
      const logoImg = new Image();
      logoImg.src = logo;
      await new Promise((res) => (logoImg.onload = res));

      // Convert HTML → Canvas
      const canvas = await html2canvas(container, {
        scale: 2,
        useCORS: true,
        windowWidth: 1100,
      });

      const imgData = canvas.toDataURL("image/png");
      const imgProps = pdf.getImageProperties(imgData);

      const pdfW = pdf.internal.pageSize.getWidth();
      const pdfH = pdf.internal.pageSize.getHeight();

      const pageHeightMM = (imgProps.height * pdfW) / imgProps.width;

      let remainingHeight = pageHeightMM;
      let startY = 0;
      const pxPerMM = canvas.height / pageHeightMM;

      let pageIndex = 0;

      // PAGE LOOP
      while (remainingHeight > 0) {
        const sliceMM = Math.min(remainingHeight, pdfH);
        const slicePX = sliceMM * pxPerMM;

        const sliceCanvas = document.createElement("canvas");
        sliceCanvas.width = canvas.width;
        sliceCanvas.height = slicePX;

        sliceCanvas
          .getContext("2d")
          .drawImage(
            canvas,
            0,
            startY,
            canvas.width,
            slicePX,
            0,
            0,
            canvas.width,
            slicePX
          );

        const sliceImg = sliceCanvas.toDataURL("image/png");

        if (pageIndex > 0) pdf.addPage();

        // PAGE CONTENT
        pdf.addImage(sliceImg, "PNG", 0, 0, pdfW, sliceMM);

        // Top-right company logo
        // pdf.addImage(logoImg, "PNG", pdfW - 40, 8, 32, 18);

        remainingHeight -= sliceMM;
        startY += slicePX;
        pageIndex++;
      }

      pdf.save("Quotation.pdf");

      container.classList.remove("pdf-mode");
      setIsPDF(false);

      // Clear window data after PDF download
      localStorage.removeItem("windowList");
    }, 300);
  };

  /* ---------- Show warning modal when windowList is empty ---------- */
  if (!windowList || windowList.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-6">
        <div className="bg-white p-6 rounded-lg shadow-md max-w-xl">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-gray-200 flex items-center justify-center rounded">
              <svg width="36" height="36" viewBox="0 0 24 24" fill="none">
                <rect
                  x="2"
                  y="3"
                  width="20"
                  height="14"
                  rx="2"
                  stroke="#4b5563"
                  strokeWidth="1.2"
                />
                <rect x="5" y="6" width="6" height="8" fill="#c7d2fe" />
                <rect x="13" y="6" width="6" height="8" fill="#e6f6ff" />
              </svg>
            </div>

            <div>
              <div className="font-semibold">Tekna Window System</div>
              <div className="text-xs text-gray-600">Placeholder logo</div>
            </div>
          </div>

          <h2 className="text-lg font-semibold mb-2">No quotation data</h2>
          <p className="text-sm text-gray-600 mb-4">
            You have not added any windows yet. Please open the Window
            Configurator and create a quotation.
          </p>

          <div className="flex gap-3">
            <button
              onClick={() => navigate("/configurator")}
              className="bg-blue-600 text-white px-4 py-2 rounded"
            >
              Open Configurator
            </button>

            <button
              onClick={() => navigate(-1)}
              className="px-4 py-2 rounded border"
            >
              Go Back
            </button>
          </div>
        </div>
      </div>
    );
  }

  /* ---------- UI ---------- */
  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-6xl mx-auto">
        {/* Top Header */}
        <div className="flex justify-between mb-6">
          <div>
            <div className="text-xl font-bold">Tekna Window System</div>
            <div className="text-gray-600 text-sm">Quotation Preview</div>
          </div>

          <div className="flex gap-3">
            <button
              onClick={() => navigate(-1)}
              className="border px-4 py-2 rounded"
            >
              <ArrowLeft size={14} /> Back
            </button>

            <button
              onClick={downloadPDF}
              className="px-4 py-2 rounded bg-blue-600 text-white"
            >
              <Download size={14} /> Download PDF
            </button>
          </div>
        </div>

        {/* MAIN CONTENT */}
        <div className="responsive-container">
          <div
            ref={mainRef}
            className="quote-wrapper bg-white rounded-xl shadow border p-8 space-y-6"
          >
            {/* Company Header */}
            <div className="flex justify-between border-b pb-4">
              <div>
                <div className="text-xl font-bold">TEKNA WINDOW SYSTEM</div>
                <div className="text-sm">VAVDI INDUSTRY AREA</div>
                <div className="text-sm">VAVDI MAIN ROAD</div>
                <div className="text-sm">TEKNA WINDOW</div>

                <div className="text-sm mt-3">
                  <div>Mobile : 9825256525</div>
                  <div>Email : TEKNAWIN01@GMAIL.COM</div>
                  <div>GSTIN : 24AMIPS5762R1Z4</div>
                </div>
              </div>

              <img
                src={logo}
                alt="TWS Logo"
                style={{ width: 160, height: "auto", objectFit: "contain" }}
              />
            </div>

            {/* WINDOW LIST */}
            <div className="space-y-10">
              {windowList.map((w, i) => (
                <div
                  key={i}
                  className="border rounded-lg p-6 bg-white shadow-sm"
                  style={{ border: "2px solid #000" }}
                >
                  <div className="flex justify-between mb-4">
                    <div className="font-semibold text-lg">
                      Window {i + 1} — {w.windowType}
                    </div>
                  </div>

                  {/* FIXED: Responsive layout */}
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                    {/* FIXED: Sketch container centers + fits mobile */}
                    <div
                      className="md:col-span-4 border p-4 flex justify-center items-center mx-auto w-full max-w-[220px]"
                      style={{ border: "1px solid #000" }}
                    >
                      <WindowSketch
                        width={w.width}
                        height={w.height}
                        type={w.windowType}
                      />
                    </div>

                    {/* DESCRIPTION BLOCK */}
                    <div className="md:col-span-8 space-y-4">
                      <div className="p-4" style={{ border: "1px solid #000" }}>
                        <div className="text-sm leading-6">
                          <div>
                            <strong>Size (Inch)</strong> : W {w.width}" × H{" "}
                            {w.height}"
                          </div>
                          <div>
                            <strong>Profile System</strong> :{" "}
                            {w.profileSystem || "-"}
                          </div>
                          <div>
                            <strong>Design</strong> : {w.design || "-"}
                          </div>
                          <div>
                            <strong>Glass</strong> : {w.glassType || "-"}
                          </div>
                          <div>
                            <strong>Locking</strong> : {w.locking || "-"}
                          </div>
                          <div>
                            <strong>Grill</strong> : {w.grill || "-"}
                          </div>
                        </div>
                      </div>

                      <div
                        className="p-4"
                        style={{
                          border: "1px solid #000",
                          background: "#f4f4f4",
                        }}
                      >
                        <div className="font-semibold mb-2">
                          Computed Values
                        </div>
                        <div className="text-sm leading-6">
                          <div>
                            <strong>Sq.ft per Window</strong> :{" "}
                            {Number(w.sqFt).toFixed(2)}
                          </div>
                          <div>
                            <strong>Rate/sq.ft</strong> :{" "}
                            {formatINR(w.pricePerFt)}
                          </div>
                          <div>
                            <strong>Quantity</strong> : {w.quantity}
                          </div>
                          <div>
                            <strong>Value</strong> : {formatINR(w.amount)}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* GST PREVIEW (INPUTS) */}
            {!isPDF && (
              <div className="mt-4 border-t pt-3">
                <div className="flex justify-between mb-2 text-sm">
                  <div>Subtotal</div>
                  <div>{formatINR(subtotal)}</div>
                </div>

                <label className="flex items-center gap-2 mt-3">
                  <input
                    type="checkbox"
                    checked={applyGST}
                    onChange={(e) => setApplyGST(e.target.checked)}
                  />
                  Apply CGST & SGST
                </label>

                {applyGST && (
                  <div className="grid grid-cols-2 gap-4 mt-3">
                    <div>
                      <div className="text-xs">CGST %</div>
                      <input
                        type="number"
                        value={cgstPerc}
                        onChange={(e) => setCgstPerc(e.target.value)}
                        className="border rounded w-full px-2 py-1"
                      />
                      <div className="text-xs mt-1">
                        Amount: {formatINR(cgstAmount)}
                      </div>
                    </div>

                    <div>
                      <div className="text-xs">SGST %</div>
                      <input
                        type="number"
                        value={sgstPerc}
                        onChange={(e) => setSgstPerc(e.target.value)}
                        className="border rounded w-full px-2 py-1"
                      />
                      <div className="text-xs mt-1">
                        Amount: {formatINR(sgstAmount)}
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex justify-between border-t pt-3 mt-3">
                  <div className="font-medium">Grand Total</div>
                  <div className="font-bold text-lg">
                    {formatINR(grandTotal)}
                  </div>
                </div>
              </div>
            )}

            {/* GST PDF DISPLAY ONLY */}
            {isPDF && (
              <div className="border rounded p-4 bg-gray-50">
                <div className="flex justify-between mb-2">
                  <div>Subtotal</div>
                  <div>{formatINR(subtotal)}</div>
                </div>

                {applyGST && (
                  <>
                    <div className="flex justify-between mb-1">
                      <div>CGST ({cgstPerc}%)</div>
                      <div>{formatINR(cgstAmount)}</div>
                    </div>
                    <div className="flex justify-between mb-2">
                      <div>SGST ({sgstPerc}%)</div>
                      <div>{formatINR(sgstAmount)}</div>
                    </div>
                  </>
                )}

                <div className="flex justify-between border-t pt-2 mt-2 font-semibold">
                  <div>Grand Total</div>
                  <div>{formatINR(grandTotal)}</div>
                </div>
              </div>
            )}

            {/* Terms */}
            <h3 className="font-semibold mb-2">Terms & Condition:</h3>

            <ul className="list-disc pl-6 space-y-1 text-sm text-gray-800">
              <li>
                QUOTATION ARE VALID UPTO 1 WEEK (RATE MAY CHANGE DEPENDING ON
                MATERIAL PRICE CHANGE).
              </li>
              <li>SIZE IS CALCULATED IN WIDTH AND HEIGHT IN 3 INCH STEPS.</li>
              <li>
                THE DESIGN AND STYLE OF PRODUCT REMAINS UNCHANGED. THE CUSTOMER
                WILL BE CHARGED FOR THAT.
              </li>
              <li>THERE IS NO WARRANTY FOR GLASS ONCE INSTALLATION IS DONE.</li>
              <li>
                FOR MANUFACTURING DEFECT, CLIENT HAS TO INFORM US WITHIN 48
                HOURS AFTER INSTALLATION. AFTER THE TIME PERIOD, TEKNA WINDOW
                SYSTEM WILL BE NOT LIABLE FOR ANY DEFECTS.
              </li>
              <li>
                SCAFFOLDING/CRANE SERVICE, ELECTRICITY, STORAGE FOR MATERIAL AND
                CLEANING OF GLASS & WINDOW WILL BE UNDER CUSTOMER'S SCOPE.
              </li>
              <li>
                ANY DAMAGE OR BREAKAGE OF STONE WILL NOT BE OUR RESPONSIBILITY.
              </li>
              <li>
                AFTER HANDOVERING WINDOWS, IF ANY SERVICE REQUIRE RELATED TO
                WINDOWS & DOORS, THAT SHOULD BE CHARGEABLE.
              </li>

              {/* Installation Time */}
              <li>
                <strong>INSTALLATION TIME:</strong>
                <ul className="list-disc pl-6 mt-1">
                  <li>
                    40 - 45 DAYS (DELIVERY TIME WILL BE SCHEDULED AT THE TIME OF
                    ADVANCE PAYMENT RECEIVED).
                  </li>
                </ul>
              </li>

              {/* Payment Terms */}
              <li>
                <strong>PAYMENT TERMS:</strong>
                <ul className="list-disc pl-6 mt-1">
                  <li>70 % ADVANCE TO CONFIRM ORDER.</li>
                  <li>20 % AGAINST MATERIAL AT READY TO DISPATCH.</li>
                  <li>10 % AFTER SUCCESSFUL INSTALLATION.</li>
                </ul>
              </li>

              <li>
                ALL DISPUTES SHALL BE SUBJECT RAJKOT CITY JURISDICTION ONLY.
              </li>
              <li>TRANSPORTATION AND GST EXTRA.</li>
            </ul>

            {/* BANK DETAILS */}
            <div className="mt-10">
              <h3 className="font-bold underline mb-4 text-sm">BANK DETAILS</h3>

              <div className="text-sm leading-7">
                <div className="flex">
                  <div className="w-40 font-semibold">BANK NAME</div>
                  <div className="mr-2">:</div>
                  <div>STATE BANK OF INDIA</div>
                </div>

                <div className="flex">
                  <div className="w-40 font-semibold">BRANCH</div>
                  <div className="mr-2">:</div>
                  <div>CHANDRESH NAGAR, MAVDI PLOT</div>
                </div>

                <div className="flex">
                  <div className="w-40 font-semibold">CURRENT A/C NO.</div>
                  <div className="mr-2">:</div>
                  <div>34200993101</div>
                </div>

                <div className="flex">
                  <div className="w-40 font-semibold">IFSC CODE</div>
                  <div className="mr-2">:</div>
                  <div>SBIN0060314</div>
                </div>
              </div>

              {/* ACCEPTANCE STATEMENT */}
              <p className="mt-8 text-sm text-center font-medium tracking-wide">
                I HEREBY ACCEPT THE ESTIMATE AS PER ABOVE MENTIONED PRICE AND
                SPECIFICATIONS. I HAVE READ AND UNDERSTOOD THE TERMS &
                CONDITIONS AND AGREE TO THEM.
              </p>

              {/* SIGNATURES */}
              <div className="flex justify-between mt-10">
                <div className="text-sm font-semibold">
                  Authorised Signatory
                </div>
                <div className="text-sm font-semibold">
                  Signature of Customer
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex justify-end gap-3 mt-6">
          <button
            className="border px-4 py-2 rounded"
            onClick={() => navigate(-1)}
          >
            Back
          </button>
          <button
            className="bg-blue-600 text-white px-4 py-2 rounded"
            onClick={downloadPDF}
          >
            Download PDF
          </button>
        </div>
      </div>
    </div>
  );
}
