import { useNavigate } from "react-router-dom";
import { useState } from "react";
import QuotesModal from "../components/Modal";

export default function Dashboard() {
  const navigate = useNavigate();

  // --------------------------
  // Modal State
  // --------------------------
  const [showQuotesModal, setShowQuotesModal] = useState(false);
  const [showProjectsModal, setShowProjectsModal] = useState(false);

  // --------------------------
  // Demo Data
  // --------------------------
  const recentQuotes = [
    {
      id: "Q-0135",
      customer: "John Doe",
      status: "Approved",
      color: "bg-green-100 text-green-700",
      amount: "$12,500.00",
    },
    {
      id: "Q-0134",
      customer: "Jane Smith",
      status: "Sent",
      color: "bg-yellow-100 text-yellow-700",
      amount: "$8,200.00",
    },
    {
      id: "Q-0133",
      customer: "Build Corp Inc.",
      status: "Draft",
      color: "bg-blue-100 text-blue-700",
      amount: "$25,000.00",
    },
    {
      id: "Q-0132",
      customer: "Mike Johnson",
      status: "Declined",
      color: "bg-red-100 text-red-700",
      amount: "$5,600.00",
    },
  ];

  const activeProjects = [
    ["P-0078", "Modern Homes LLC", "In Production", "2024-08-15"],
    ["P-0077", "City Tower Group", "Awaiting Installation", "2024-07-30"],
    ["P-0075", "Riverfront Apartments", "Fabrication", "2024-09-01"],
  ];

  return (
    <div className="space-y-6">
      {/* Greeting */}
      <div className="flex flex-wrap items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-gray-800">Hello</h2>
          <p className="text-gray-500 text-sm">
            Here's a quick overview of your activities.
          </p>
        </div>

        <button
          onClick={() => navigate("/configurator")}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition"
        >
          New Quote
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {[
          {
            title: "Quotes Awaiting Approval",
            value: 12,
            trend: "+5.2%",
            color: "text-green-600",
          },
          {
            title: "Active Projects",
            value: 5,
            trend: "-1.0%",
            color: "text-red-500",
          },
          {
            title: "Completed This Month",
            value: 8,
            trend: "+15.0%",
            color: "text-green-600",
          },
        ].map((card, i) => (
          <div key={i} className="bg-white rounded-xl border p-5 shadow-sm">
            <p className="text-gray-500 text-sm">{card.title}</p>
            <h3 className="text-2xl font-semibold mt-2">{card.value}</h3>
            <p className={`text-xs mt-1 font-medium ${card.color}`}>
              {card.trend}
            </p>
          </div>
        ))}
      </div>

      {/* Recent Quotes */}
      <div className="bg-white rounded-xl border shadow-sm p-5">
        <div className="flex justify-between items-center mb-3">
          <h3 className="font-semibold text-gray-800">Recent Quotes</h3>

          <div className="flex gap-4">
            <button
              className="text-blue-600 text-sm font-medium"
              onClick={() => setShowQuotesModal(true)}
            >
              View All
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-gray-500 text-left border-b">
                <th className="py-2">Quote ID</th>
                <th>Customer</th>
                <th>Status</th>
                <th>Amount</th>
                <th></th>
              </tr>
            </thead>

            <tbody>
              {recentQuotes.map((row, i) => (
                <tr key={i} className="border-b">
                  <td className="py-2">{row.id}</td>
                  <td>{row.customer}</td>
                  <td>
                    <span
                      className={`px-2 py-1 text-xs rounded-lg ${row.color}`}
                    >
                      {row.status}
                    </span>
                  </td>
                  <td>{row.amount}</td>

                  {/* INLINE VIEW BUTTON */}
                  <td>
                    <button
                      className="text-blue-600 hover:underline"
                      onClick={() => navigate(`/quote/${row.id}`)}
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quotes Modal */}
      {showQuotesModal && (
        <QuotesModal
          title="All Quotes"
          data={recentQuotes}
          onClose={() => setShowQuotesModal(false)}
          onView={(id) => navigate(`/quote/${id}`)}
        />
      )}

      {/* Projects Modal */}
      {showProjectsModal && (
        <QuotesModal
          title="Active Projects"
          data={activeProjects.map((p) => ({
            id: p[0],
            customer: p[1],
            status: p[2],
            amount: p[3],
            color: "bg-blue-100 text-blue-700",
          }))}
          onClose={() => setShowProjectsModal(false)}
          onView={(id) => navigate(`/projects/${id}`)}
        />
      )}
    </div>
  );
}
