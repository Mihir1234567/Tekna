import Navbar from "./components/Navbar";
import { Routes, Route, useLocation } from "react-router-dom";

import Dashboard from "./pages/Dashboard";
import Configurator from "./pages/Configurator";
import Quotes from "./pages/Quotes";
import QuoteDetails from "./pages/QuoteDetails";
import Login from "./pages/Login";
import Register from "./pages/Register";

export default function App() {
  const location = useLocation();

  // Routes where navbar must NOT appear
  const hideNavbarRoutes = ["/", "/login", "/register"];

  const hideNavbar = hideNavbarRoutes.includes(location.pathname);

  return (
    <div className="flex flex-col min-h-screen bg-[#F5F7FA]">
      {/* SHOW NAVBAR ONLY WHEN NOT ON LOGIN/REGISTER */}
      {!hideNavbar && <Navbar />}

      <main className={`flex-1 p-6 ${!hideNavbar ? "mt-2" : ""}`}>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/configurator" element={<Configurator />} />
          <Route path="/quotes" element={<Quotes />} />
          <Route path="/quote/:id" element={<QuoteDetails />} />
        </Routes>
      </main>
    </div>
  );
}
