import { X } from "lucide-react";

export default function QuotesModal({ title, data, onClose, onView }) {
  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex justify-center items-center z-50 p-4">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-xl overflow-hidden animate-fadeIn">
        {/* HEADER */}
        <div className="flex justify-between items-center px-6 py-4 border-b bg-gray-50">
          <h2 className="text-xl font-semibold text-gray-800">{title}</h2>

          <button
            onClick={onClose}
            className="text-gray-600 hover:text-gray-800"
          >
            <X size={22} />
          </button>
        </div>

        {/* CONTENT */}
        <div className="max-h-[70vh] overflow-y-auto p-6 space-y-4">
          {data.map((q, i) => (
            <div
              key={i}
              className="border rounded-xl p-4 bg-white shadow-sm hover:shadow-md transition cursor-default"
            >
              <div className="flex justify-between items-center">
                {/* LEFT SIDE */}
                <div>
                  <p className="text-sm text-gray-500">Quote ID</p>
                  <p className="font-semibold text-gray-800">{q.id}</p>

                  <p className="mt-1 text-sm text-gray-500">Customer</p>
                  <p className="font-medium">{q.customer}</p>
                </div>

                {/* STATUS */}
                <span
                  className={`px-3 py-1 rounded-full text-xs font-medium ${q.color}`}
                >
                  {q.status}
                </span>

                {/* ACTIONS */}
                <button
                  onClick={() => onView(q.id)}
                  className="text-blue-600 font-medium hover:underline"
                >
                  View →
                </button>
              </div>

              {/* AMOUNT */}
              <div className="mt-3 text-sm text-gray-600">
                <span className="font-medium">Amount:</span> {q.amount}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
