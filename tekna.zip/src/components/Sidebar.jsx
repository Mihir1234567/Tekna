import { NavLink } from "react-router-dom";
import { Home, Layers, FileText } from "lucide-react";

const menu = [
  { name: "Dashboard", path: "/", icon: <Home size={18} /> },
  {
    name: "Window Configurator",
    path: "/configurator",
    icon: <Layers size={18} />,
  },
  { name: "Quotations", path: "/quotes", icon: <FileText size={18} /> },
];

export default function Sidebar() {
  return (
    <aside className="w-64 border-r bg-white h-screen flex flex-col px-4 py-6">
      <h1 className="text-2xl font-bold text-blue-600 mb-10">TeknaGlass</h1>

      <nav className="space-y-2">
        {menu.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-2 font-medium rounded-lg transition-all
              ${
                isActive
                  ? "bg-blue-600 text-white shadow-sm"
                  : "text-gray-700 hover:bg-gray-100"
              }`
            }
          >
            {item.icon}
            {item.name}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
