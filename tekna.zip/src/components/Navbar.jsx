import { NavLink, useNavigate } from "react-router-dom";
import { Menu } from "lucide-react";
import { useState } from "react";
import MobileSidebar from "./MobileSidebar";

const navLinks = [
  { label: "Dashboard", path: "/dashboard" },
  { label: "Window Configurator", path: "/configurator" },
  { label: "Quotation Preview", path: "/quotes" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("auth");
    navigate("/login");
  };

  return (
    <>
      <header className="h-16 w-full bg-white border-b shadow-sm flex items-center justify-between px-4 md:px-6">
        {/* Mobile Menu */}
        <button
          className="lg:hidden p-2 rounded-lg hover:bg-gray-100"
          onClick={() => setOpen(true)}
        >
          <Menu size={22} className="text-gray-700" />
        </button>

        {/* Logo */}
        <div
          onClick={() => {
            navigate("/dashboard");
          }}
          className="text-xl font-semibold text-blue-600"
        >
          TEKNA
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-6">
          {navLinks.map((link) => (
            <NavLink
              key={link.path}
              to={link.path}
              className={({ isActive }) =>
                `text-sm font-medium pb-1 transition ${
                  isActive
                    ? "text-blue-600 border-b-2 border-blue-600"
                    : "text-gray-600 hover:text-gray-900"
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>

        {/* Right Profile + Logout */}
        <div className="flex items-center gap-4">
          <button
            onClick={handleLogout}
            className="hidden lg:block px-4 py-2 bg-red-500 text-white text-sm rounded-lg hover:bg-red-600 transition"
          >
            Logout
          </button>
        </div>
      </header>

      {/* Mobile Sidebar */}
      <MobileSidebar open={open} setOpen={setOpen} navLinks={navLinks} />
    </>
  );
}
