import { Canvas } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";

export default function Window3D({ width, height, windowType }) {
  const W = width * 0.025;
  const H = height * 0.025;

  const frame = 0.07;
  const glassInset = 0.02;
  const glassW = W - frame * 2;
  const glassH = H - frame * 2;

  // ✅ SLIDER WINDOW — Perfect Matching Style
  if (windowType === "slider") {
    const frameColor = "#2E3A43";
    const sashThickness = 0.05; // thin sliders like normal frame
    const depth = 0.05;
    const glassDepthFront = -0.015;
    const glassDepthBack = -0.025;

    return (
      <Canvas camera={{ position: [2, 2, 3.2], fov: 50 }}>
        <ambientLight intensity={0.7} />
        <directionalLight position={[5, 5, 5]} intensity={1.1} />

        {/* LEFT FRAME */}
        <mesh position={[-W / 2 + sashThickness / 2, H / 2, 0]}>
          <boxGeometry args={[sashThickness, H, depth]} />
          <meshStandardMaterial
            color={frameColor}
            metalness={0.6}
            roughness={0.3}
          />
        </mesh>

        {/* RIGHT FRAME */}
        <mesh position={[W / 2 - sashThickness / 2, H / 2, 0]}>
          <boxGeometry args={[sashThickness, H, depth]} />
          <meshStandardMaterial
            color={frameColor}
            metalness={0.6}
            roughness={0.3}
          />
        </mesh>

        {/* TOP FRAME */}
        <mesh position={[0, H - sashThickness / 2, 0]}>
          <boxGeometry args={[W, sashThickness, depth]} />
          <meshStandardMaterial
            color={frameColor}
            metalness={0.6}
            roughness={0.3}
          />
        </mesh>

        {/* BOTTOM FRAME */}
        <mesh position={[0, sashThickness / 2, 0]}>
          <boxGeometry args={[W, sashThickness, depth]} />
          <meshStandardMaterial
            color={frameColor}
            metalness={0.6}
            roughness={0.3}
          />
        </mesh>

        {/* CENTER DIVIDER */}
        <mesh position={[0, H / 2, depth / 2]}>
          <boxGeometry args={[sashThickness, H - sashThickness * 2, depth]} />
          <meshStandardMaterial color={frameColor} />
        </mesh>

        {/* LEFT GLASS SASH */}
        <mesh position={[-W / 4, H / 2, glassDepthFront]}>
          <boxGeometry
            args={[W / 2 - sashThickness * 2, H - sashThickness * 2, 0.01]}
          />
          <meshPhysicalMaterial
            color="#A5D6E7"
            transparent
            opacity={0.45}
            transmission={1}
            clearcoat={0.9}
            clearcoatRoughness={0.08}
            roughness={0.15}
          />
        </mesh>

        {/* RIGHT GLASS SASH (slightly behind) */}
        <mesh position={[W / 4, H / 2, glassDepthBack]}>
          <boxGeometry
            args={[W / 2 - sashThickness * 2, H - sashThickness * 2, 0.01]}
          />
          <meshPhysicalMaterial
            color="#A5D6E7"
            transparent
            opacity={0.45}
            transmission={1}
            clearcoat={0.9}
            clearcoatRoughness={0.08}
            roughness={0.15}
          />
        </mesh>

        <OrbitControls />
      </Canvas>
    );
  }

  // ✅ NORMAL WINDOW MODEL
  return (
    <Canvas camera={{ position: [2, 2, 3], fov: 50 }}>
      <ambientLight intensity={0.7} />
      <directionalLight position={[5, 5, 5]} intensity={1} />

      {/* Left frame */}
      <mesh position={[-W / 2 + frame / 2, H / 2, 0]}>
        <boxGeometry args={[frame, H, frame]} />
        <meshStandardMaterial color="#2E3A43" metalness={0.6} roughness={0.3} />
      </mesh>

      {/* Right frame */}
      <mesh position={[W / 2 - frame / 2, H / 2, 0]}>
        <boxGeometry args={[frame, H, frame]} />
        <meshStandardMaterial color="#2E3A43" metalness={0.6} roughness={0.3} />
      </mesh>

      {/* Top frame */}
      <mesh position={[0, H - frame / 2, 0]}>
        <boxGeometry args={[W, frame, frame]} />
        <meshStandardMaterial color="#2E3A43" metalness={0.6} roughness={0.3} />
      </mesh>

      {/* Bottom frame */}
      <mesh position={[0, frame / 2, 0]}>
        <boxGeometry args={[W, frame, frame]} />
        <meshStandardMaterial color="#2E3A43" metalness={0.6} roughness={0.3} />
      </mesh>

      {/* Glass */}
      <mesh position={[0, H / 2, -glassInset]}>
        <boxGeometry args={[glassW, glassH, 0.01]} />
        <meshPhysicalMaterial
          color="#A5D6E7"
          transparent
          opacity={0.4}
          transmission={1}
          clearcoat={0.8}
          clearcoatRoughness={0.1}
        />
      </mesh>

      <OrbitControls />
    </Canvas>
  );
}
