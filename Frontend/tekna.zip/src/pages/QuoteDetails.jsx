// src/pages/QuoteDetails.jsx
import React, { useEffect, useRef, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { ArrowLeft, Download } from "lucide-react";

/* Format INR */
function formatINR(v) {
  const n = Number(v) || 0;
  return "₹" + n.toLocaleString("en-IN", { minimumFractionDigits: 2 });
}

/* ---- Window Sketch SVG ---- */
function WindowSketch({ width = 36, height = 48, type = "normal" }) {
  const W = Number(width);
  const H = Number(height);

  const boxW = 220;
  const boxH = 160;

  const aspect = W / H;
  let rectW = aspect > boxW / boxH ? boxW : Math.round(boxH * aspect);
  let rectH = aspect > boxW / boxH ? Math.round(boxW / aspect) : boxH;

  const offsetX = (boxW - rectW) / 2 + 24;
  const offsetY = (boxH - rectH) / 2 + 10;

  const frame = "#0b1220";
  const glass = "#dbeffc";
  const sliderLeft = "#cbd6da";

  return (
    <svg width={boxW + 120} height={boxH + 90}>
      <rect
        x={offsetX - 6}
        y={offsetY - 6}
        width={rectW + 12}
        height={rectH + 12}
        fill={frame}
        rx={6}
      />

      <rect
        x={offsetX - 2}
        y={offsetY - 2}
        width={rectW + 4}
        height={rectH + 4}
        fill="#0b1220"
        rx={4}
      />

      {type === "slider" ? (
        <>
          <rect
            x={offsetX}
            y={offsetY}
            width={rectW / 2}
            height={rectH}
            fill={sliderLeft}
            rx={3}
          />
          <rect
            x={offsetX + rectW / 2}
            y={offsetY}
            width={rectW / 2}
            height={rectH}
            fill={glass}
            rx={3}
          />
          <rect
            x={offsetX + rectW / 2 - 3}
            y={offsetY - 6}
            width={6}
            height={rectH + 12}
            fill={frame}
          />
        </>
      ) : (
        <rect
          x={offsetX}
          y={offsetY}
          width={rectW}
          height={rectH}
          fill={glass}
          rx={3}
        />
      )}

      <rect
        x={offsetX}
        y={offsetY}
        width={rectW}
        height={rectH}
        fill="none"
        stroke={frame}
        strokeWidth={2}
      />
    </svg>
  );
}

/* ---------------- Quote Details Component ---------------- */
export default function QuoteDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const containerRef = useRef(null);

  const [quote, setQuote] = useState(null);

  // GST State
  const [applyGST, setApplyGST] = useState(true);
  const cgstPerc = 9;
  const sgstPerc = 9;

  /* Load from localStorage */
  useEffect(() => {
    const savedQuotes = JSON.parse(localStorage.getItem("quotes") || "[]");
    const found = savedQuotes.find((q) => q.id === id);
    if (found) setQuote(found);
  }, [id]);

  /* Fallback mock data */
  // useEffect(() => {
  //   if (!quote) {
  //     setTimeout(() => {
  //       setQuote({
  //         id: id || "Q-0001",
  //         windowList: [
  //           {
  //             windowType: "Sliding",
  //             width: 48,
  //             height: 54,
  //             profileSystem: "Tekna Premium",
  //             design: "2 Track 2 Panel",
  //             glassType: "5mm Clear Glass",
  //             locking: "Normal",
  //             grill: "No Grill",
  //             sqFt: 17.5,
  //             pricePerFt: 850,
  //             quantity: 2,
  //             amount: 14875,
  //           },
  //           {
  //             windowType: "Casement",
  //             width: 36,
  //             height: 48,
  //             profileSystem: "Tekna Elite",
  //             design: "Openable Window",
  //             glassType: "6mm Toughened",
  //             locking: "Crescent",
  //             grill: "Premium Grill",
  //             sqFt: 12,
  //             pricePerFt: 950,
  //             quantity: 1,
  //             amount: 11400,
  //           },
  //         ],
  //       });
  //     }, 150);
  //   }
  // }, [quote, id]);

  if (!quote) {
    return (
      <div className="p-6 text-center text-gray-600">
        Loading quote preview...
      </div>
    );
  }

  /* GST Calculations */
  const subtotal = quote.windowList.reduce(
    (s, w) => s + Number(w.amount || 0),
    0
  );
  const cgstAmount = applyGST ? (subtotal * cgstPerc) / 100 : 0;
  const sgstAmount = applyGST ? (subtotal * sgstPerc) / 100 : 0;
  const grandTotal = subtotal + cgstAmount + sgstAmount;

  /* PDF Download */
  const downloadPDF = async () => {
    const container = containerRef.current;
    container.classList.add("pdf-mode");

    setTimeout(async () => {
      const pdf = new jsPDF("p", "mm", "a4");
      const canvas = await html2canvas(container, {
        scale: 2,
        useCORS: true,
        windowWidth: 900,
      });

      const img = canvas.toDataURL("image/png");
      const pdfW = pdf.internal.pageSize.getWidth();
      const pdfH = pdf.internal.pageSize.getHeight();

      const props = pdf.getImageProperties(img);
      const pageHeightMM = (props.height * pdfW) / props.width;

      let remaining = pageHeightMM;
      let start = 0;
      const pxPerMM = canvas.height / pageHeightMM;

      while (remaining > 0) {
        const sliceMM = Math.min(remaining, pdfH);
        const slicePX = sliceMM * pxPerMM;

        const sliceCanvas = document.createElement("canvas");
        sliceCanvas.width = canvas.width;
        sliceCanvas.height = slicePX;

        sliceCanvas
          .getContext("2d")
          .drawImage(
            canvas,
            0,
            start,
            canvas.width,
            slicePX,
            0,
            0,
            canvas.width,
            slicePX
          );

        pdf.addImage(
          sliceCanvas.toDataURL("image/png"),
          "PNG",
          0,
          0,
          pdfW,
          sliceMM
        );

        remaining -= sliceMM;
        start += slicePX;
        if (remaining > 0) pdf.addPage();
      }

      pdf.save(`Quote-${quote.id}.pdf`);
      container.classList.remove("pdf-mode");
    }, 300);
  };

  return (
    <div className="p-6">
      {/* Top Buttons */}
      <div className="flex justify-between mb-6 max-w-5xl mx-auto">
        <button
          onClick={() => navigate(-1)}
          className="border px-4 py-2 rounded"
        >
          <ArrowLeft size={14} /> Back
        </button>

        <button
          onClick={downloadPDF}
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          <Download size={14} /> Download PDF
        </button>
      </div>

      {/* Content */}
      <div className="responsive-container">
        <div
          ref={containerRef}
          className="quote-wrapper bg-white border shadow p-8 rounded-xl max-w-5xl mx-auto"
        >
          <h2 className="text-xl font-bold mb-6">
            Quote Details — #{quote.id}
          </h2>

          {/* Windows */}
          <div className="space-y-10">
            {quote.windowList.map((w, i) => (
              <div
                key={i}
                className="border p-6 rounded-lg"
                style={{ border: "2px solid #000" }}
              >
                <h3 className="text-lg font-semibold mb-4">
                  Window {i + 1} — {w.windowType}
                </h3>

                <div className="grid grid-cols-12 gap-6">
                  {/* Sketch */}
                  <div className="col-span-4 flex justify-center items-center border p-4">
                    <WindowSketch
                      width={w.width}
                      height={w.height}
                      type={w.windowType}
                    />
                  </div>

                  {/* Details */}
                  <div className="col-span-8 space-y-4">
                    <div className="p-4" style={{ border: "1px solid #000" }}>
                      <div>
                        <strong>Size (Inch)</strong>: W {w.width}" × H{" "}
                        {w.height}"
                      </div>
                      <div>
                        <strong>Profile System</strong>: {w.profileSystem}
                      </div>
                      <div>
                        <strong>Design</strong>: {w.design}
                      </div>
                      <div>
                        <strong>Glass</strong>: {w.glassType}
                      </div>
                      <div>
                        <strong>Locking</strong>: {w.locking}
                      </div>
                      <div>
                        <strong>Grill</strong>: {w.grill}
                      </div>
                    </div>

                    <div
                      className="p-4 bg-gray-100"
                      style={{ border: "1px solid #000" }}
                    >
                      <h4 className="font-semibold mb-2">Computed Values</h4>
                      <div>
                        <strong>Sq.ft per Window</strong>:{" "}
                        {Number(w.sqFt).toFixed(2)}
                      </div>
                      <div>
                        <strong>Rate/sq.ft</strong>: {formatINR(w.pricePerFt)}
                      </div>
                      <div>
                        <strong>Quantity</strong>: {w.quantity}
                      </div>
                      <div>
                        <strong>Value</strong>: {formatINR(w.amount)}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* GST / Total Section */}
          <div className="mt-10 p-5 border rounded-lg bg-gray-50 shadow-sm">
            <h3 className="font-semibold text-lg mb-3">Price Summary</h3>

            <div className="flex justify-between text-sm mb-2">
              <span>Subtotal</span>
              <span>{formatINR(subtotal)}</span>
            </div>

            {applyGST && (
              <>
                <div className="flex justify-between text-sm mb-2">
                  <span>CGST ({cgstPerc}%)</span>
                  <span>{formatINR(cgstAmount)}</span>
                </div>
                <div className="flex justify-between text-sm mb-2">
                  <span>SGST ({sgstPerc}%)</span>
                  <span>{formatINR(sgstAmount)}</span>
                </div>
              </>
            )}

            <div className="flex justify-between font-bold text-lg border-t pt-3 mt-3">
              <span>Grand Total</span>
              <span>{formatINR(grandTotal)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
