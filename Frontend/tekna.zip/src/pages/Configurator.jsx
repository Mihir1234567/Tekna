// src/pages/Configurator.jsx
import { useState } from "react";
import Window3D from "../components/Window3D";
import {
  RotateCw,
  ZoomIn,
  Trash2,
  AlertCircle,
  Edit3,
  XCircle,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { div } from "three/tsl";

export default function Configurator() {
  const [width, setWidth] = useState(36);
  const [height, setHeight] = useState(48);
  const [quantity, setQuantity] = useState(1);
  const [windowType, setWindowType] = useState("normal");
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    profileSystem: "",
    design: "",
    glassType: "",
    grill: "",
    locking: "",
    hardware: "",
    pricePerFt: "",
  });

  const [windowList, setWindowList] = useState([]);
  const [errors, setErrors] = useState({});
  const [bannerError, setBannerError] = useState("");
  const [editIndex, setEditIndex] = useState(null); // track edit mode

  const requiredFields = [
    ["profileSystem", "Profile System"],
    ["design", "Design"],
    ["glassType", "Glass Type"],
    ["grill", "Grill"],
    ["locking", "Locking"],
    ["hardware", "Hardware"],
  ];

  const validateFields = () => {
    const newErrors = {};

    // ✅ Height & width validation
    if (!height || Number(height) <= 0)
      newErrors.height = "Enter valid height.";
    if (!width || Number(width) <= 0) newErrors.width = "Enter valid width.";

    // ✅ pricePerFt check (safe for both string or number)
    const priceStr = String(formData.pricePerFt || "").trim();
    const ppf = Number(priceStr);
    if (!priceStr || isNaN(ppf) || ppf <= 0)
      newErrors.pricePerFt = "Price/ft must be a number > 0.";

    // ✅ Required text fields
    requiredFields.forEach(([key, label]) => {
      const value = (formData[key] || "").toString().trim();
      if (!value) newErrors[key] = `${label} is required.`;
    });

    setErrors(newErrors);
    const ok = Object.keys(newErrors).length === 0;
    setBannerError(ok ? "" : "Please fix highlighted fields before saving.");
    return ok;
  };

  const handleAddOrUpdateWindow = () => {
    if (!validateFields()) return; // ✅ now safe and won't break update

    const h = Number(height);
    const w = Number(width);
    const p = Number(formData.pricePerFt);
    const q = Number(quantity);
    const sqFt = (h / 12) * (w / 12);
    const amount = sqFt * p * q;

    const entry = {
      width: w,
      height: h,
      quantity: q,
      windowType,
      ...formData,
      pricePerFt: p,
      sqFt: Number(sqFt.toFixed(2)),
      amount: Number(amount.toFixed(2)),
    };

    if (editIndex !== null) {
      // ✅ update existing window
      const updatedList = [...windowList];
      updatedList[editIndex] = entry;
      setWindowList(updatedList);
      setEditIndex(null);
    } else {
      // ✅ add new window
      setWindowList((prev) => [...prev, entry]);
    }

    resetForm();
  };

  const resetForm = () => {
    setWidth(36);
    setHeight(48);
    setQuantity(1);
    setWindowType("normal");
    setFormData({
      profileSystem: "",
      design: "",
      glassType: "",
      grill: "",
      locking: "",
      hardware: "",
      pricePerFt: "",
    });
    setErrors({});
    setBannerError("");
  };

  const removeWindow = (i) => {
    setWindowList(windowList.filter((_, idx) => idx !== i));
    if (editIndex === i) setEditIndex(null);
  };

  const editWindow = (i) => {
    const w = windowList[i];
    setWidth(w.width);
    setHeight(w.height);
    setQuantity(w.quantity);
    setWindowType(w.windowType);
    setFormData({
      profileSystem: w.profileSystem,
      design: w.design,
      glassType: w.glassType,
      grill: w.grill,
      locking: w.locking,
      hardware: w.hardware,
      pricePerFt: w.pricePerFt,
    });
    setEditIndex(i);
    setBannerError("");
  };

  const cancelEdit = () => {
    resetForm();
    setEditIndex(null);
  };

  const totalSqFt = windowList
    .reduce((sum, w) => sum + w.sqFt * w.quantity, 0)
    .toFixed(2);

  const totalAmount = windowList
    .reduce((sum, w) => sum + w.amount, 0)
    .toFixed(2);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 px-4 py-4">
      {/* LEFT PANEL */}
      <div className="lg:col-span-3 bg-white rounded-2xl border shadow-sm p-5 space-y-5">
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-semibold mb-3">
            {editIndex !== null ? "Edit Window" : "Specifications"}
          </h2>
          {editIndex !== null && (
            <button
              onClick={cancelEdit}
              className="text-xs text-red-600 flex items-center gap-1 hover:text-red-700"
            >
              <XCircle size={14} /> Cancel
            </button>
          )}
        </div>

        {/* Height */}
        <div>
          <label className="text-sm font-medium text-gray-700">
            Height (in)
          </label>
          <input
            type="number"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            className={`w-full border rounded-lg px-3 py-2 mt-1 text-sm ${
              errors.height ? "border-red-500" : ""
            }`}
          />
          {errors.height && (
            <p className="text-xs text-red-500">{errors.height}</p>
          )}
        </div>

        {/* Width */}
        <div>
          <label className="text-sm font-medium text-gray-700">
            Width (in)
          </label>
          <input
            type="number"
            value={width}
            onChange={(e) => setWidth(e.target.value)}
            className={`w-full border rounded-lg px-3 py-2 mt-1 text-sm ${
              errors.width ? "border-red-500" : ""
            }`}
          />
          {errors.width && (
            <p className="text-xs text-red-500">{errors.width}</p>
          )}
        </div>

        {/* Window Type */}
        <div>
          <label className="text-sm font-medium text-gray-700">
            Window Type
          </label>
          <div className="grid grid-cols-2 gap-2 mt-1">
            {["normal", "slider"].map((type) => (
              <button
                key={type}
                onClick={() => setWindowType(type)}
                className={`px-3 py-2 rounded-lg text-sm border ${
                  windowType === type
                    ? "bg-blue-600 text-white border-blue-600"
                    : "bg-white text-gray-700"
                }`}
              >
                {type[0].toUpperCase() + type.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Text Inputs */}
        {[
          ["profileSystem", "Profile System"],
          ["design", "Design"],
          ["glassType", "Glass Type"],
          ["grill", "Grill"],
          ["locking", "Locking"],
          ["hardware", "Hardware"],
          ["pricePerFt", "Price/ft"],
        ].map(([key, label]) => (
          <div key={key}>
            <label className="text-sm text-gray-700 font-medium">{label}</label>
            <input
              type={key === "pricePerFt" ? "number" : "text"}
              value={formData[key]}
              onChange={(e) =>
                setFormData({ ...formData, [key]: e.target.value })
              }
              className={`w-full border mt-1 rounded-lg px-3 py-2 text-sm ${
                errors[key] ? "border-red-500" : ""
              }`}
              placeholder={`Enter ${label}`}
            />
            {errors[key] && (
              <p className="text-xs text-red-500">{errors[key]}</p>
            )}
          </div>
        ))}

        {/* Quantity */}
        <div>
          <label className="text-sm font-medium text-gray-700">Quantity</label>
          <div className="flex border rounded-lg mt-1">
            <button
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              className="px-3 py-2 border-r"
            >
              -
            </button>
            <span className="flex-1 text-center px-2 py-2">{quantity}</span>
            <button
              onClick={() => setQuantity(quantity + 1)}
              className="px-3 py-2 border-l"
            >
              +
            </button>
          </div>
        </div>

        {/* Banner Error */}
        {bannerError && (
          <div className="flex items-start gap-2 text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg p-2">
            <AlertCircle size={14} />
            {bannerError}
          </div>
        )}

        <button
          onClick={handleAddOrUpdateWindow}
          className={`w-full ${
            editIndex !== null ? "bg-yellow-500" : "bg-green-600"
          } text-white py-2 rounded-lg text-sm`}
        >
          {editIndex !== null ? "Update Window" : "+ Add Window"}
        </button>
      </div>

      {/* 3D Preview */}
      <div className="lg:col-span-6 bg-gray-100 rounded-2xl border h-[75vh] flex items-center justify-center relative">
        <Window3D
          width={width || 0}
          height={height || 0}
          windowType={windowType}
        />
      </div>

      {/* Right Panel */}
      <div className="lg:col-span-3 bg-white rounded-2xl border shadow-sm p-5 space-y-4">
        <h2 className="text-lg font-semibold">Windows in this order</h2>

        {windowList.length === 0 ? (
          <div className="text-xs text-gray-500 border rounded-lg p-3 bg-gray-50">
            No windows added yet.
          </div>
        ) : (
          <ul className="max-h-64 overflow-auto pr-1 space-y-2">
            {windowList.map((w, i) => (
              <li
                key={i}
                className={`rounded-lg border bg-white shadow-sm p-3 ${
                  editIndex === i ? "border-yellow-400 bg-yellow-50" : ""
                }`}
              >
                <div className="flex justify-between items-center">
                  <p className="text-sm font-medium">Window {i + 1}</p>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-50 text-blue-600 border">
                    {w.windowType}
                  </span>
                </div>

                <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-[11px] text-gray-700">
                  <div>
                    Size: {w.width}" × {w.height}"
                  </div>
                  <div>Qty: {w.quantity}</div>
                  <div>Profile: {w.profileSystem}</div>
                  <div>Design: {w.design}</div>
                  <div>Glass: {w.glassType}</div>
                  <div>Grill: {w.grill}</div>
                  <div>Locking: {w.locking}</div>
                  <div>Hardware: {w.hardware}</div>
                  <div>SqFt: {w.sqFt}</div>
                  <div>Rate: ₹{w.pricePerFt}</div>
                  <div className="col-span-2 font-semibold">
                    Amount: ₹{w.amount}
                  </div>
                </div>

                <div className="mt-2 flex gap-2">
                  <button
                    onClick={() => editWindow(i)}
                    className="inline-flex items-center gap-1 text-xs text-blue-600 hover:bg-blue-50 px-2 py-1 rounded-md"
                  >
                    <Edit3 size={14} /> Edit
                  </button>
                  <button
                    onClick={() => removeWindow(i)}
                    className="inline-flex items-center gap-1 text-xs text-red-600 hover:bg-red-50 px-2 py-1 rounded-md"
                  >
                    <Trash2 size={14} /> Remove
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
        <hr />
        {windowList.length === 0 ? (
          <></>
        ) : (
          <div>
            <h2 className="text-lg font-semibold">Quote Summary</h2>
            <div className="text-sm space-y-1">
              <div className="flex justify-between">
                <span>Total Sq Ft</span>
                <span>{totalSqFt}</span>
              </div>
              <div className="flex justify-between">
                <span>Grand Total</span>
                <span>₹{totalAmount}</span>
              </div>
            </div>

            <div className="flex justify-between text-blue-600 font-bold text-lg pt-2 border-t">
              <span>Total</span>
              <span>₹{totalAmount}</span>
            </div>

            <button
              onClick={() =>
                navigate("/quotes", {
                  state: { windowList, totalSqFt, totalAmount },
                })
              }
              className="w-full bg-blue-600 text-white py-2 rounded-lg text-sm"
            >
              Generate Quote
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
